import { GlobalStateSlot } from '@mui/utils/generateUtilityClass';
export declare function generateUtilityClass(componentName: string, slot: string | GlobalStateSlot): string;
export declare function isGlobalState(slot: string): boolean;
