export declare function generateUtilityClasses<T extends string>(componentName: string, slots: T[]): Record<T, string>;
