'use client';

export { MultiSelect } from './MultiSelect';