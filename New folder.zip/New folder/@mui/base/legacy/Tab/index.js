'use client';

export { Tab } from './Tab';
export * from './Tab.types';
export * from './tabClasses';