'use client';

export { Tabs } from './Tabs';
export * from './TabsContext';
export * from './tabsClasses';
export * from './Tabs.types';