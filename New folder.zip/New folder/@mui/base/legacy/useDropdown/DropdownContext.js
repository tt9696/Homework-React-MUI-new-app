import * as React from 'react';
var DropdownContext = /*#__PURE__*/React.createContext(null);
if (process.env.NODE_ENV !== 'production') {
  DropdownContext.displayName = 'DropdownContext';
}
export { DropdownContext };