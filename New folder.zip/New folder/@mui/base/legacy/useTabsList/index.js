'use client';

export { useTabsList } from './useTabsList';
export * from './useTabsList.types';
export * from './TabsListProvider';