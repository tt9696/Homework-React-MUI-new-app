export var TabsListActionTypes = {
  valueChange: 'valueChange'
};