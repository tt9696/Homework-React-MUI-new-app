import * as React from 'react';
export var TransitionContext = /*#__PURE__*/React.createContext(null);
if (process.env.NODE_ENV !== 'production') {
  TransitionContext.displayName = 'TransitionContext';
}