import * as React from 'react';
export const PopupContext = /*#__PURE__*/React.createContext(null);
if (process.env.NODE_ENV !== 'production') {
  PopupContext.displayName = 'PopupContext';
}