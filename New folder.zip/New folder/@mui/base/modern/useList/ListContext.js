import * as React from 'react';
export const ListContext = /*#__PURE__*/React.createContext(null);
if (process.env.NODE_ENV !== 'production') {
  ListContext.displayName = 'ListContext';
}